# Independent auditor handoff

This bundle targets exact Git revision `da92dd173b34f8ab0f389e4850deaf33e415e419` and bundle `sha256:07e689d3c70d61ba7a7a32aa469173be2a15f0023f840f2795d7a563ee1102a3`. It is a handoff, not an audit verdict, launch approval, or statement that an external audit is complete. Its timestamps are commit/package metadata and never evidence of elapsed public-testnet, Quiet Week, canary, or other real public time.

1. Verify `bundle-manifest.json`, every listed SHA-256, and the source revision independently.
2. Use `audit-scope.json`, `threat-model-inventory.json`, and the six workstream source trees. Record all scope exceptions.
3. Obtain an external auditor-roster entry for the report key. A self-declared random key is not sufficient.
4. Complete `auditor-independence.json`; declarations are signed assertions, not machine proof of human independence.
5. Complete `audit-report.json`. Findings are append-only hash-chained events under `finding-lifecycle.json`. Waivers and risk acceptance never close a finding. An S1 must end in auditor-authored `resolved_verified`.
6. Hash every attachment into the report, then sign the exact raw `audit-report.json` bytes with detached Ed25519 and complete `audit-report.signature.json`.
7. Run `python tools/audit/ingest_report.py --bundle <bundle.zip> --submission <directory> --auditor-roster <external-roster.json> --as-of <real-current-UTC-time>`. Acceptance means evidence-package integrity only; it cannot pass G3/G5 or edit claim state.

No private key is included. Any keys created by the deterministic test suite are ephemeral and explicitly test-only; they are not production signatures.
