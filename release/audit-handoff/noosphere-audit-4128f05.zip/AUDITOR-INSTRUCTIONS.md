# Independent auditor handoff

This bundle targets exact Git revision `4128f05e662e15b55beb8340879f90f1f7097d90` and bundle `sha256:24e6b7092038c031630e0017e2b444d0bb01e1b016731880a4827fa018e1f7e8`. It is a handoff, not an audit verdict, launch approval, or statement that an external audit is complete. Its timestamps are commit/package metadata and never evidence of elapsed public-testnet, Quiet Week, canary, or other real public time.

1. Obtain the repository/worktree or trusted Git object database independently. Run `python tools/audit/verify_handoff.py <bundle.zip> --repo <trusted-repository> --revision 4128f05e662e15b55beb8340879f90f1f7097d90`. A bundle cannot establish its own revision trust root.
2. Verify `bundle-manifest.json`, every listed SHA-256, every packaged source byte/mode/blob against `<revision>:<path>`, and independently recompute the packaged RISC Zero method ID.
3. Use `audit-scope.json`, `threat-model-inventory.json`, and the six workstream source trees. Record all scope exceptions.
4. Obtain an external auditor-roster entry for the report key. A self-declared random key is not sufficient.
5. Complete `auditor-independence.json`; declarations are signed assertions, not machine proof of human independence.
6. Complete `audit-report.json`. Findings are append-only hash-chained events under `finding-lifecycle.json`. Waivers and risk acceptance never close a finding. An S1 must end in auditor-authored `resolved_verified`.
7. Hash every attachment into the report, then sign the exact raw `audit-report.json` bytes with detached Ed25519 and complete `audit-report.signature.json`.
8. Run `python tools/audit/ingest_report.py --bundle <bundle.zip> --submission <directory> --auditor-roster <external-roster.json> --as-of <real-current-UTC-time>`. Acceptance means evidence-package integrity only; it cannot pass G3/G5 or edit claim state.

No private key is included. Any keys created by the deterministic test suite are ephemeral and explicitly test-only; they are not production signatures.
